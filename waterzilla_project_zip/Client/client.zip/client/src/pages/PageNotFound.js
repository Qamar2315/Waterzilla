import React from 'react'

function PageNotFound(props) {
  return (
    <div>{props.error}</div>
  )
}

export default PageNotFound;